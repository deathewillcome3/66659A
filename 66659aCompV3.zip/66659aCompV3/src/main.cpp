/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Sun Jan 2 2021                                            */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
 
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// FrontL               motor         12              
// BackL                motor         11              
// FrontR               motor         2               
// BackR                motor         1               
// Arm1                 motor         19              
// Arm2                 motor         10              
// armClamp             motor         20              
// BackArm              motor         21              
// Iner                 inertial      15              
// ---- END VEXCODE CONFIGURED DEVICES ----
 
#include "vex.h"
#include <cmath>
#include <iostream>
using namespace vex;
using namespace std;
 
// A global instance of competition
competition Competition;
 
// define your global instances of motors and other devices here
void turn2point(double rel_angle, double init_angle);
void travel2point(double t_dist, double max_sped);
void strafeLeft(double time2drift);
void strafeRight(double time2drift);
void forwardDrive(double t);
void backwardDrive(double t);
void turnL(double t);
void turnR(double t);

//AUTONS//
void rightRings();
void leftTower();
void LneutralTower();
void RneutralTower();
void doubleAuton();
void programmingSkills();

//helpful
void clamp();
void unclamp();
void raiseArm();
void lowerArm();
void backUp(char type);
void backDown(char type);
void auton();
void callibrateInertial();
void exactR(int dg);
void exactL(int deg);

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
 
void pre_auton(void) {
 // Initializing Robot Configuration. DO NOT REMOVE!
 vexcodeInit();
 callibrateInertial();

 // All activities that occur before the competition starts
 // Example: clearing encoders, setting servo positions, ...
}
 
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
  

void autonomous(void) {
  // LneutralTower();
  // RneutralTower();
  // rightRings();
  // leftTower();
  // doubleAuton();
  // programmingSkills();
  // auton();
 }
 
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
 
// WITH COMP FIELD THING
// forwardDrive(0.42); == 1 tile
// turnR(0.97); == 90deg


/*-* __/^-^\__ *-*/
 void usercontrol(void) {
// callibrateInertial();
Iner.resetHeading();


while (1) {

// User control code here, inside the loop
// bool armUp = false;
// double unit = 0.32;
// double deg = (0.57/90);

// if((Controller1.ButtonUp.pressing()) && (armUp == false)){
//   armUp = true;
//   raiseArm();
// }
// if((Controller1.ButtonDown.pressing()) && (armUp == true)){
//   armUp = false;
//   lowerArm();
// }

// if(armUp == false){
//   if(Controller1.ButtonUp.pressing()){
//     raiseArm();
//     armUp = true;
//   }
// }
// else if(armUp == true){
//   if(Controller1.ButtonDown.pressing()){
//     lowerArm();
//     armUp = false;
//   }
// }

if(Controller1.ButtonY.pressing()){
  programmingSkills();
}
if(Controller1.ButtonA.pressing()){
  exactR(90);
}



// if(Controller1.ButtonUp.pressing()){
//   backUp('f');
// }
// if(Controller1.ButtonDown.pressing()){
//   backDown('f');
// }

//Movement code
//change percent speed of back vs forward for turning
// double a4 = pow(Controller1.Axis4.value()/100, 3) *  800;
// double a3 = pow(Controller1.Axis3.value()/100, 3) * 800;
double a4 = (Controller1.Axis4.value()/100);
double a3 = (Controller1.Axis3.value()/100);
FrontL.spin(directionType::fwd, 127*(a4 + a3), velocityUnits::pct);
FrontR.spin(directionType::fwd, 127*(a4 - a3), velocityUnits::pct);
BackL.spin(directionType::fwd, 127*(a4 + a3), velocityUnits::pct);
BackR.spin(directionType::fwd, 127*(a4 - a3), velocityUnits::pct);

//drifting time bois
if(abs(Controller1.Axis1.value()) >=6){
 if(Controller1.Axis1.value() < -6){
   FrontL.spin(directionType::rev, 127, velocityUnits::pct);
   BackL.spin(directionType::fwd, 127, velocityUnits::pct);
   FrontR.spin(directionType::rev, 127, velocityUnits::pct);
   BackR.spin(directionType::fwd, 127, velocityUnits::pct);
 }
 else if(Controller1.Axis1.value() > 6){
   FrontL.spin(directionType::fwd, 127, velocityUnits::pct);
   BackL.spin(directionType::rev, 127, velocityUnits::pct);
   FrontR.spin(directionType::fwd, 127, velocityUnits::pct);
   BackR.spin(directionType::rev, 127, velocityUnits::pct);
 }
}
//Arm
if(Controller1.ButtonR2.pressing()){
 Arm1.spin(directionType::rev, 300, velocityUnits::pct);
 Arm2.spin(directionType::fwd, 300, velocityUnits::pct);
}
else if(Controller1.ButtonR1.pressing()){
 Arm1.spin(directionType::fwd, 300, velocityUnits::pct);
 Arm2.spin(directionType::rev, 300, velocityUnits::pct);
}
else{
 Arm1.stop(brakeType::hold);
 Arm2.stop(brakeType::hold);
}
//  Back arm
if(Controller1.ButtonL1.pressing()){
 BackArm.spin(directionType::rev, 127, velocityUnits::pct);
}
else if(Controller1.ButtonL2.pressing()){
 BackArm.spin(directionType::fwd, 127, velocityUnits::pct);
}
else{
 BackArm.stop(brakeType::hold);
}
//Clamp
if(Controller1.ButtonX.pressing()){
 armClamp.spin(directionType::rev, 500, velocityUnits::pct);
}
else if((Controller1.ButtonB.pressing())){
 armClamp.spin(directionType::fwd, 500, velocityUnits::pct);
}
else{
 armClamp.stop(brakeType::hold);
}
}
}
//
// Main will set up the competition functions and callbacks.
//
int main() {
// Set up callbacks for autonomous and driver control periods.
Competition.autonomous(autonomous);
Competition.drivercontrol(usercontrol);
// Run the pre-autonomous function.
pre_auton();
// Prevent main from exiting with an infinite loop.
  while (true) {
  wait(100, msec);
  }
}
void turn2point(double rel_angle, double init_angle){
double theta = init_angle;
double whl_rad = 0.05;
double rbt_w = 0.4064;
double response = 0;
int prev_time = vex::timer::system();
double dt = 0.01;
while (abs(theta - rel_angle) > 0.1){
 response = (rel_angle - theta) * 10;
 dt = ((double) vex::timer::system() - prev_time) / 1000;
 double ave_whl_rev = (FrontL.velocity(rpm) + BackL.velocity(rpm) + FrontR.velocity(rpm) + BackL.velocity(rpm))/4;
 ave_whl_rev = ave_whl_rev * 2 * 3.14 /60;
 theta = theta + (ave_whl_rev * whl_rad / (rbt_w/2)) * dt;
 FrontL.spin(directionType::fwd, response, velocityUnits::pct);
 BackL.spin(directionType::fwd, response, velocityUnits::pct);
 FrontR.spin(directionType::fwd, response, velocityUnits::pct);
 BackR.spin(directionType::fwd, response, velocityUnits::pct);
 prev_time = vex::timer::system();
}
}
void travel2point(double t_dist, double max_sped){
 double dist = 0;
 double main_response = 0;
 double side_response = 0;
 double whl_rad = 0.05;
 int prev_time = vex::timer::system();
 double dt = 0.01;
 while (abs(dist - t_dist) > 0.05){
   dt = ((double) vex::timer::system() - prev_time) / 1000;
   main_response = (dist - t_dist) * 0.4;
   main_response = min(max_sped, max(-1*max_sped, main_response))*100;
   double lrpm = (FrontL.velocity(rpm) + BackL.velocity(rpm))/2;
   double rrpm = -1 * (FrontR.velocity(rpm) + BackR.velocity(rpm))/2;
   side_response = (rrpm - lrpm) * 0.1;
   dist = dist + whl_rad*(lrpm*0.5 + rrpm*0.5) * 2 * 3.14 / 60;
   prev_time = vex::timer::system();
   side_response = min(max_sped, max(-1*max_sped, side_response))*100;
   FrontL.spin(directionType::fwd, (side_response + main_response), velocityUnits::pct);
   FrontR.spin(directionType::fwd, (side_response - main_response), velocityUnits::pct);
   BackL.spin(directionType::fwd, (side_response + main_response), velocityUnits::pct);
   BackR.spin(directionType::fwd, (side_response - main_response), velocityUnits::pct);
 }
}
void strafeLeft(double time2drift){
FrontL.spin(directionType::rev, 60, velocityUnits::pct);
BackL.spin(directionType::fwd, 60, velocityUnits::pct);
FrontR.spin(directionType::rev, 60, velocityUnits::pct);
BackR.spin(directionType::fwd, 60, velocityUnits::pct);
wait(time2drift, sec);
FrontL.spin(directionType::rev, 0, velocityUnits::pct);
BackL.spin(directionType::fwd, 0, velocityUnits::pct);
FrontR.spin(directionType::rev, 0, velocityUnits::pct);
BackR.spin(directionType::fwd, 0, velocityUnits::pct);
}
void strafeRight(double time2drift){
FrontL.spin(directionType::fwd, 60, velocityUnits::pct);
BackL.spin(directionType::rev, 60, velocityUnits::pct);
FrontR.spin(directionType::fwd, 60, velocityUnits::pct);
BackR.spin(directionType::rev, 60, velocityUnits::pct);
wait(time2drift, sec);
FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
BackL.spin(directionType::rev, 0, velocityUnits::pct);
FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
BackR.spin(directionType::rev, 0, velocityUnits::pct);
}
void forwardDrive(double t){
FrontL.spin(directionType::fwd, 80, velocityUnits::pct);
BackL.spin(directionType::fwd, 80, velocityUnits::pct);
FrontR.spin(directionType::rev, 80, velocityUnits::pct);
BackR.spin(directionType::rev, 80, velocityUnits::pct);
wait(t, sec);
FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
BackL.spin(directionType::fwd, 0, velocityUnits::pct);
FrontR.spin(directionType::rev, 0, velocityUnits::pct);
BackR.spin(directionType::rev, 0, velocityUnits::pct);
}
void backwardDrive(double t){
FrontL.spin(directionType::rev, 80, velocityUnits::pct);
BackL.spin(directionType::rev, 80, velocityUnits::pct);
FrontR.spin(directionType::fwd, 80, velocityUnits::pct);
BackR.spin(directionType::fwd, 80, velocityUnits::pct);
wait(t, sec);
FrontL.spin(directionType::rev, 0, velocityUnits::pct);
BackL.spin(directionType::rev, 0, velocityUnits::pct);
FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
BackR.spin(directionType::fwd, 0, velocityUnits::pct);
}
void turnL(double t){
FrontL.spin(directionType::rev, 70, velocityUnits::pct);
BackL.spin(directionType::rev, 70, velocityUnits::pct);
FrontR.spin(directionType::rev, 70, velocityUnits::pct);
BackR.spin(directionType::rev, 70, velocityUnits::pct);
wait(t, sec);
FrontL.spin(directionType::rev, 0, velocityUnits::pct);
BackL.spin(directionType::rev, 0, velocityUnits::pct);
FrontR.spin(directionType::rev, 0, velocityUnits::pct);
BackR.spin(directionType::rev, 0, velocityUnits::pct);
}
void turnR(double t){
FrontL.spin(directionType::fwd, 70, velocityUnits::pct);
BackL.spin(directionType::fwd, 70, velocityUnits::pct);
FrontR.spin(directionType::fwd, 70, velocityUnits::pct);
BackR.spin(directionType::fwd, 70, velocityUnits::pct);
wait(t, sec);
FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
BackL.spin(directionType::fwd, 0, velocityUnits::pct);
FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
BackR.spin(directionType::fwd, 0, velocityUnits::pct);
}

void rightRings(){
  double time = 1;
  // //lift arm
  Arm1.spin(directionType::fwd, 50, velocityUnits::pct);
  Arm2.spin(directionType::rev, 50, velocityUnits::pct);
  forwardDrive(time * 0.29);
  wait(0.28, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);
  // //drive to tower
  // //release rings
  armClamp.spin(directionType::rev, 55, velocityUnits::pct);
  wait(0.6, sec);
  armClamp.stop(brakeType::hold);
  // //adjust
  FrontL.spin(directionType::rev, 60, velocityUnits::pct);
  BackL.spin(directionType::rev, 60, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 60, velocityUnits::pct);
  BackR.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.07, sec);
  FrontL.spin(directionType::rev, 0, velocityUnits::pct);
  BackL.spin(directionType::rev, 0, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
  BackR.spin(directionType::fwd, 0, velocityUnits::pct);
  // //strafe little to right
  strafeRight(0.3);
  turnR(0.1);
  strafeLeft(0.3);
  backwardDrive(time * 0.2);
  //clamp
  armClamp.spin(directionType::fwd, 50, velocityUnits::pct);
  wait(0.5, sec);
  armClamp.stop(brakeType::hold);
  //lower arm to pick up
  Arm1.spin(directionType::rev, 40, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 40, velocityUnits::pct);
  wait(0.69, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);
  //clamp up
  armClamp.spin(directionType::rev, 80, velocityUnits::pct);
  wait(0.65, sec);
  armClamp.stop(brakeType::hold);
  //fwd & clamp
  FrontL.spin(directionType::fwd, 30, velocityUnits::pct);
  BackL.spin(directionType::fwd, 30, velocityUnits::pct);
  FrontR.spin(directionType::rev, 30, velocityUnits::pct);
  BackR.spin(directionType::rev, 30, velocityUnits::pct);
  armClamp.spin(directionType::rev, 50, velocityUnits::pct);
  wait(0.4, sec);
  armClamp.stop(brakeType::hold);
  wait(0.51, sec);
  FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
  BackL.spin(directionType::fwd, 0, velocityUnits::pct);
  FrontR.spin(directionType::rev, 0, velocityUnits::pct);
  BackR.spin(directionType::rev, 0, velocityUnits::pct);

  armClamp.spin(directionType::fwd, 70, velocityUnits::pct);
  wait(1.1, sec);
  armClamp.stop(brakeType::hold);
  //backward
  backwardDrive(time * 0.43);

  //unclamp
  armClamp.spin(directionType::rev, 65, velocityUnits::pct);
  wait(0.8, sec);
  armClamp.stop(brakeType::hold);
  //back up
  backwardDrive(0.4);

  wait(0.3, sec);
  // //open
  // BackArm.spin(directionType::rev, 80, velocityUnits::pct);
  // wait(0.6, sec);
  // BackArm.spin(directionType::rev, 0, velocityUnits::pct);

  //line it up
  strafeLeft(0.5);
 
  FrontL.spin(directionType::fwd, 127, velocityUnits::pct);
  BackL.spin(directionType::fwd, 127, velocityUnits::pct);
  FrontR.spin(directionType::rev, 127, velocityUnits::pct);
  BackR.spin(directionType::rev, 127, velocityUnits::pct);
  wait(1.5, sec);
  FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
  BackL.spin(directionType::fwd, 0, velocityUnits::pct);
  FrontR.spin(directionType::rev, 0, velocityUnits::pct);
  BackR.spin(directionType::rev, 0, velocityUnits::pct);  


  //clamp
  armClamp.spin(directionType::fwd, 90, velocityUnits::pct);
  wait(0.7, sec);
  armClamp.stop(brakeType::hold);
  //bring it back
  backwardDrive(1.2);
  turnL(1);
  raiseArm();
}

void leftTower(){
  strafeLeft(0.29);
  forwardDrive(0.4);
  wait(0.4, sec);
  Arm1.spin(directionType::fwd, 60, velocityUnits::pct);
  Arm2.spin(directionType::rev, 60, velocityUnits::pct);
  wait(0.4, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);

  //release rings
  armClamp.spin(directionType::rev, 55, velocityUnits::pct);
  wait(0.6, sec);
  armClamp.stop(brakeType::hold);

  //adjust
  FrontL.spin(directionType::rev, 60, velocityUnits::pct);
  BackL.spin(directionType::rev, 60, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 60, velocityUnits::pct);
  BackR.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.07, sec);
  FrontL.spin(directionType::rev, 0, velocityUnits::pct);
  BackL.spin(directionType::rev, 0, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
  BackR.spin(directionType::fwd, 0, velocityUnits::pct);

  turnL(0.55);
  unclamp();

  Arm1.spin(directionType::rev, 60, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.5, sec);
  Arm1.spin(directionType::rev, 0, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 0, velocityUnits::pct);


  armClamp.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.5, sec);
  armClamp.stop(brakeType::hold);
  forwardDrive(1.7);
  clamp();

  backwardDrive(1.5);
  turnL(2);
  forwardDrive(1);
  raiseArm();

  // // //strafe little to right
  // strafeRight(0.27);
  // turnR(0.1);
  // backwardDrive(0.2);
  // // //circle left
  // strafeLeft(3.8);

  // Arm1.spin(directionType::rev, 60, velocityUnits::pct);
  // Arm2.spin(directionType::fwd, 60, velocityUnits::pct);
  // wait(0.4, sec);
  // Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  // Arm2.spin(directionType::rev, 0, velocityUnits::pct);

  // armClamp.spin(directionType::rev, 60, velocityUnits::pct);
  // wait(0.3, sec);
  // armClamp.stop(brakeType::hold);

  // forwardDrive(0.8);
  // armClamp.spin(directionType::fwd, 70, velocityUnits::pct);
  // wait(0.6, sec);
  // armClamp.stop(brakeType::hold);

  // forwardDrive(0.5);
} 

void LneutralTower(){
  double time = 1;
  FrontL.spin(directionType::fwd, 200, velocityUnits::pct);
  BackL.spin(directionType::fwd, 200, velocityUnits::pct);
  FrontR.spin(directionType::rev, 200, velocityUnits::pct);
  BackR.spin(directionType::rev, 200, velocityUnits::pct);
  wait(1.4, sec);
  FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
  BackL.spin(directionType::fwd, 0, velocityUnits::pct);
  FrontR.spin(directionType::rev, 0, velocityUnits::pct);
  BackR.spin(directionType::rev, 0, velocityUnits::pct);
  armClamp.spin(directionType::fwd, 127, velocityUnits::pct);
  wait(0.6, sec);
  armClamp.stop(brakeType::hold);



  backwardDrive(1.7 * time);
  turnL(0.75);
  forwardDrive(0.2);
  strafeLeft(3);
  backwardDrive(0.2);
  strafeRight(0.3);
  forwardDrive(0.4);
  backDown('f');
  backwardDrive(2.3);
  backUp('t');
  forwardDrive(1.2 );
}

void RneutralTower(){
  double time = 1;
  FrontL.spin(directionType::fwd, 127, velocityUnits::pct);
  BackL.spin(directionType::fwd, 127, velocityUnits::pct);
  FrontR.spin(directionType::rev, 127, velocityUnits::pct);
  BackR.spin(directionType::rev, 127, velocityUnits::pct);
  wait(1.4, sec);
  FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
  BackL.spin(directionType::fwd, 0, velocityUnits::pct);
  FrontR.spin(directionType::rev, 0, velocityUnits::pct);
  BackR.spin(directionType::rev, 0, velocityUnits::pct);
  armClamp.spin(directionType::fwd, 127, velocityUnits::pct);
  wait(0.6, sec);
  armClamp.stop(brakeType::hold);

  Arm1.spin(directionType::fwd, 90, velocityUnits::pct);
  Arm2.spin(directionType::rev, 90, velocityUnits::pct);
  wait(0.1, sec);
  Arm1.stop(brakeType::hold);
  Arm2.stop(brakeType::hold);

  backwardDrive(0.5 * time);
  turnL(0.45);
  backDown('f');
  backwardDrive(0.8);
  backUp('t');

}

void doubleAuton(){
  forwardDrive(0.1);
  strafeLeft(0.3);
  forwardDrive(0.3);

  Arm1.spin(directionType::fwd, 75, velocityUnits::pct);
  Arm2.spin(directionType::rev, 75, velocityUnits::pct);
  wait(0.19, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);

  //release rings
  armClamp.spin(directionType::rev, 40, velocityUnits::pct);
  wait(0.3, sec);
  armClamp.stop(brakeType::hold);
  wait(0.3, sec);
  armClamp.spin(directionType::fwd, 55, velocityUnits::pct);
  wait(0.3, sec);
  armClamp.stop(brakeType::hold);

  //adjust
  FrontL.spin(directionType::rev, 60, velocityUnits::pct);
  BackL.spin(directionType::rev, 60, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 60, velocityUnits::pct);
  BackR.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.8, sec);
  FrontL.spin(directionType::rev, 0, velocityUnits::pct);
  BackL.spin(directionType::rev, 0, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
  BackR.spin(directionType::fwd, 0, velocityUnits::pct);

  strafeLeft(1.5);
  

  FrontL.spin(directionType::rev, 60, velocityUnits::pct);
  BackL.spin(directionType::rev, 60, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 60, velocityUnits::pct);
  BackR.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.4, sec);
  FrontL.spin(directionType::rev, 0, velocityUnits::pct);
  BackL.spin(directionType::rev, 0, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
  BackR.spin(directionType::fwd, 0, velocityUnits::pct);  

  

  forwardDrive(3.1);
  strafeRight(0.3);

  Arm1.spin(directionType::fwd, 75, velocityUnits::pct);
  Arm2.spin(directionType::rev, 75, velocityUnits::pct);
  wait(0.15, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);
  
  forwardDrive(0.2);

  armClamp.spin(directionType::rev, 60, velocityUnits::pct);
  wait(0.5, sec);
  armClamp.stop(brakeType::hold);

  backwardDrive(0.7);
  strafeLeft(0.5);
  forwardDrive(0.8);
  strafeRight(1.3);
}







void programmingSkills(){
  double unit = 0.36;
  double deg = (0.61/90);
  unclamp();
  //first red
  backDown('f');
  backwardDrive(unit);
  backUp('f');
  forwardDrive(unit);
  strafeRight(unit);
  //line with wall
  turnR(0.6);
  backwardDrive(0.4*unit);

  //left neutral
  forwardDrive(3.5*unit);

  turnR(15*deg);
  forwardDrive(4*unit);
  clamp();
  turnR(10*deg);
  //stack neutral left
  raiseArm();
  //extra
  Arm1.spin(directionType::fwd, 60, velocityUnits::pct);
  Arm2.spin(directionType::rev, 60, velocityUnits::pct);
  wait(0.2, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);  
  forwardDrive(4.6*unit);
  turnL(60*deg);
  turnR(30*deg);
  forwardDrive(unit);
  Arm1.spin(directionType::rev, 80, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 80, velocityUnits::pct);
  wait(0.5, sec);
  Arm1.spin(directionType::rev, 0, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 0, velocityUnits::pct); 


  unclamp();

  Arm1.spin(directionType::fwd, 40, velocityUnits::pct);
  Arm2.spin(directionType::rev, 40, velocityUnits::pct);
  wait(0.5, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct); 
  //blue
  backwardDrive(unit);
  lowerArm();

  Arm1.spin(directionType::rev, 60, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.3, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);  

  turnL(90*deg);
  strafeRight(1.5*unit);
  strafeLeft(0.7*unit);

  //place tower on back
  BackArm.spin(directionType::fwd, 127, velocityUnits::pct);
  wait(0.83, sec);
  BackArm.stop(brakeType::hold);

  //red right
  forwardDrive(5.3*unit);
  backUp('t');
  backUp('t');
  clamp();

  armClamp.spin(directionType::fwd, 60, velocityUnits::pct);
  wait(0.2, sec);
  armClamp.stop(brakeType::hold);

  Arm1.spin(directionType::fwd, 60, velocityUnits::pct);
  Arm2.spin(directionType::rev, 60, velocityUnits::pct);
  wait(0.2, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);  

  backwardDrive(5*unit);
  strafeLeft(12*unit);
  //blue right
  strafeRight(0.5*unit);
  unclamp();
  backwardDrive(1.5*unit);
  strafeLeft(unit);
  backDown('f');
  backwardDrive(6*unit);
  backUp('f');
  //right neutral
  forwardDrive(2*unit);
  strafeRight(5.5*unit);
  
  BackArm.spin(directionType::fwd, 127, velocityUnits::pct);
  wait(0.85, sec);
  BackArm.stop(brakeType::hold);
  backwardDrive(1.5*unit);
  forwardDrive(unit);
  backUp('f');


}





void ps(){
  // //chris
  // // double unit = 0.42;
  // // double deg = (0.97/90);

  // //comp @ bancroft
  // double unit = 0.32;
  // double deg = (0.57/90);


  // //blue right
  // unclamp();
  // forwardDrive(1.7*unit);

  // clamp();
  // backwardDrive(1.5*unit);
  // strafeLeft(1.5*unit);

  // turnR(125*deg);

  // wait(0.2, sec);

  // backwardDrive(unit);
  // Arm1.spin(directionType::fwd, 75, velocityUnits::pct);
  // Arm2.spin(directionType::rev, 75, velocityUnits::pct);
  // wait(0.3, sec);
  // Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  // Arm2.spin(directionType::rev, 0, velocityUnits::pct);  

  // wait(0.2, sec);

  // //neutral
  // backwardDrive(8.5*unit);
  // unclamp();
  // forwardDrive(unit);
  // //right
  // backwardDrive(1.5*unit);
  // strafeRight(4.5*unit);
  // backwardDrive(2*unit);
  // strafeRight(2*unit);
  // strafeLeft(unit);
  // forwardDrive(9*unit);

  // backwardDrive(2.5*unit);
  // strafeLeft(5*unit);
  // //left neutral
  // backwardDrive(5*unit);
  // strafeLeft(3*unit);

  // forwardDrive(7*unit);
  // backwardDrive(2*unit);
  // //left other
  // strafeLeft(4*unit);
  // backwardDrive(8*unit);

  // strafeLeft(3*unit);
  // strafeRight(1.5*unit);
  
  // forwardDrive(8*unit);
  // clamp();
  // backwardDrive(9.5*unit);
}

void clamp(){
  armClamp.spin(directionType::fwd, 127, velocityUnits::pct);
  wait(0.735, sec);
  armClamp.stop(brakeType::hold);
}
void unclamp(){
  armClamp.spin(directionType::rev, 127, velocityUnits::pct);
  wait(0.725, sec);
  armClamp.stop(brakeType::hold);
}
void raiseArm(){
  Arm1.spin(directionType::fwd, 90, velocityUnits::pct);
  Arm2.spin(directionType::rev, 90, velocityUnits::pct);
  armClamp.spin(directionType::rev, 100, velocityUnits::pct);
  wait(0.2, sec);
  armClamp.stop(brakeType::hold);
  wait(1, sec);
  Arm1.spin(directionType::fwd, 0, velocityUnits::pct);
  Arm2.spin(directionType::rev, 0, velocityUnits::pct);
}
void lowerArm(){
  Arm1.spin(directionType::rev, 90, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 90, velocityUnits::pct);
  armClamp.spin(directionType::fwd, 100, velocityUnits::pct);
  wait(0.2, sec);
  armClamp.stop(brakeType::hold);
  wait(1, sec);
  Arm1.spin(directionType::rev, 0, velocityUnits::pct);
  Arm2.spin(directionType::fwd, 0, velocityUnits::pct);
}

void backUp(char type){
  if(type == 'f'){
    BackArm.spin(directionType::rev, 127, velocityUnits::pct);
    wait(0.88, sec);
    BackArm.stop(brakeType::hold);
  }
  else if(type == 't'){
    BackArm.spin(directionType::rev, 127, velocityUnits::pct);
    wait(0.56, sec);
    BackArm.stop(brakeType::hold);
  }
}

void backDown(char type){
  if(type == 'f'){
    BackArm.spin(directionType::fwd, 127, velocityUnits::pct);
    wait(0.88, sec);
    BackArm.stop(brakeType::hold);
  }
  else if(type == 't'){
    BackArm.spin(directionType::fwd, 127, velocityUnits::pct);
    wait(0.56, sec);
    BackArm.stop(brakeType::hold);
  }
}

void callibrateInertial(){
  Iner.calibrate();
  task::sleep(1000);
}

void exactR(int dg){
  callibrateInertial();
  Iner.resetHeading();
  FrontL.spin(directionType::fwd, 50, velocityUnits::pct);
  BackL.spin(directionType::fwd, 50, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 50, velocityUnits::pct);
  BackR.spin(directionType::fwd, 50, velocityUnits::pct);
  while(Iner.heading(rotationUnits::deg) <= dg) {
    wait(20, msec);
    Brain.Screen.clearLine(1,vex::color::black);
    Brain.Screen.clearLine(2,vex::color::black);
    Brain.Screen.setCursor(1,0);
    Brain.Screen.print("      ");
    Brain.Screen.print(Iner.heading(degrees));
    wait(20, msec);
  }
  FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
  BackL.spin(directionType::fwd, 0, velocityUnits::pct);
  FrontR.spin(directionType::fwd, 0, velocityUnits::pct);
  BackR.spin(directionType::fwd, 0, velocityUnits::pct);
}

void exactL(int deg){
  
}

void auton(){
  double time = 1;
  FrontL.spin(directionType::fwd, 127, velocityUnits::pct);
  BackL.spin(directionType::fwd, 127, velocityUnits::pct);
  FrontR.spin(directionType::rev, 127, velocityUnits::pct);
  BackR.spin(directionType::rev, 127, velocityUnits::pct);
  wait(1.4, sec);
  FrontL.spin(directionType::fwd, 0, velocityUnits::pct);
  BackL.spin(directionType::fwd, 0, velocityUnits::pct);
  FrontR.spin(directionType::rev, 0, velocityUnits::pct);
  BackR.spin(directionType::rev, 0, velocityUnits::pct);
  armClamp.spin(directionType::fwd, 127, velocityUnits::pct);
  wait(0.6, sec);
  armClamp.stop(brakeType::hold);

  Arm1.spin(directionType::fwd, 90, velocityUnits::pct);
  Arm2.spin(directionType::rev, 90, velocityUnits::pct);
  wait(0.1, sec);
  Arm1.stop(brakeType::hold);
  Arm2.stop(brakeType::hold);

  backwardDrive(1.5 * time);
  turnL(0.3);
  strafeRight(3);
  backDown('f');
  backwardDrive(1.5);
  backUp('t');
  forwardDrive(1);
}
